$(document).ready(function(){
    //FLIP CARD//
    $('.flip-card').flip({
        axis: 'x',
        trigger: 'click',
        speed: 350,
    });
});